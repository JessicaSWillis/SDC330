public class StudentStorage {

}
